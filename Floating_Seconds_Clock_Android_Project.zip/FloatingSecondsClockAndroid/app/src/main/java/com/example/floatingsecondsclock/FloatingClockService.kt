package com.example.floatingsecondsclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FloatingClockService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var use24Hour = true
    private var lastX = 0
    private var lastY = 0
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    private val tick = object : Runnable {
        override fun run() {
            bubble?.text = SimpleDateFormat(
                if (use24Hour) "HH:mm:ss" else "hh:mm:ss a",
                Locale.getDefault()
            ).format(Date())
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
        handler.post(tick)
    }

    private fun createNotification() {
        val channelId = "floating_clock_channel"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Floating clock", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setContentTitle("Floating Seconds Clock")
            .setContentText("The floating clock is active")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(19, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(19, notification)
        }
    }

    private fun showBubble() {
        val density = resources.displayMetrics.density
        bubble = TextView(this).apply {
            text = "00:00:00"
            textSize = 18f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding((14 * density).toInt(), (9 * density).toInt(), (14 * density).toInt(), (9 * density).toInt())
            setBackgroundColor(Color.argb(235, 15, 24, 42))
            elevation = 10f
            contentDescription = "Floating clock. Tap to change time format; drag to move."
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * density).toInt()
            y = (100 * density).toInt()
        }

        bubble?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = params.x
                    lastY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) moved = true
                    params.x = lastX + dx
                    params.y = lastY + dy
                    try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        use24Hour = !use24Hour
                        view.performClick()
                    }
                    true
                }
                else -> false
            }
        }
        bubble?.setOnClickListener {
            // Tap toggles 24-hour and 12-hour display.
            bubble?.text = SimpleDateFormat(if (use24Hour) "HH:mm:ss" else "hh:mm:ss a", Locale.getDefault()).format(Date())
        }
        try {
            wm.addView(bubble, params)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
