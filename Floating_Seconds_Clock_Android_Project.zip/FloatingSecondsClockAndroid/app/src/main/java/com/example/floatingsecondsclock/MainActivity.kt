package com.example.floatingsecondsclock

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 2104

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(0xFF0A1020.toInt())
        }

        val title = TextView(this).apply {
            text = "Floating Seconds Clock"
            textSize = 25f
            setTextColor(0xFFF5F7FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        }
        val description = TextView(this).apply {
            text = "Show a live clock with seconds above other apps. The Android system status-bar clock itself cannot be changed by this app."
            textSize = 15f
            setTextColor(0xFFBAC6DE.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        }
        val start = makeButton("Show floating clock")
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, requestOverlay)
            } else {
                startClock()
            }
        }
        val stop = makeButton("Hide floating clock")
        stop.setOnClickListener {
            stopService(Intent(this, FloatingClockService::class.java))
            Toast.makeText(this, "Floating clock hidden", Toast.LENGTH_SHORT).show()
        }
        val hint = TextView(this).apply {
            text = "\nTip: drag the clock bubble to move it. Tap the bubble to switch between 12-hour and 24-hour time."
            textSize = 13f
            setTextColor(0xFF8F9DB9.toInt())
            setPadding(0, pad, 0, 0)
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(start, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = pad / 2 })
        layout.addView(stop, LinearLayout.LayoutParams(-1, -2))
        layout.addView(hint)
        setContentView(layout)
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
    }

    private fun startClock() {
        val intent = Intent(this, FloatingClockService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        Toast.makeText(this, "Floating clock started", Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) startClock()
    }
}
