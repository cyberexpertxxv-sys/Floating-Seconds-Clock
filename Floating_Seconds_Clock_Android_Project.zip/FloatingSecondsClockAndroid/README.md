# Floating Seconds Clock (Android Studio project)

This is a native Android source project for a movable floating clock overlay that displays hours, minutes, and seconds over other apps.

## Important limitation
Android apps cannot change the actual system status-bar clock without device/system-level support. This app displays a separate floating clock bubble instead.

## Build APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `FloatingSecondsClockAndroid` folder.
4. Let Gradle sync. Use JDK 17 and Android SDK 35.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your phone and install it. Android may ask permission to install apps from that source.

## Use
1. Open Floating Seconds Clock.
2. Tap **Show floating clock**.
3. Allow **Display over other apps**.
4. Return to the app; the floating clock should appear.
5. Drag the bubble to move it. Tap it to switch 12/24-hour format.
6. Use **Hide floating clock** to stop it.

## Notes
- Android may stop the service due to battery restrictions. If so, allow background activity for the app in system settings.
- This source project is a starter project; building requires Android Studio and Android SDK. An APK is not included.
